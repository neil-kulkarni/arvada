#!/usr/bin/python3
import sys
from lark import Lark

target_grammar = """
start: stmt
stmt : "L" SPACE "=" SPACE numexpr
  | "if" SPACE boolexpr SPACE "then" SPACE stmt SPACE "else" SPACE stmt
  | stmt SPACE ";" SPACE stmt
  | "while" SPACE boolexpr SPACE "do" SPACE stmt
  | "skip"

boolexpr : "true" | "false" | numexpr SPACE "==" SPACE numexpr | boolexpr SPACE "&" SPACE boolexpr | "~" boolexpr

numexpr : "L" | "n" | "(" numexpr "+" numexpr ")"

SPACE: " "
"""

def main():
    if len(sys.argv) != 2:
        print("Usage: sample_lark.py <input-file>")
        exit(1)

    in_file = sys.argv[1]
    parser = Lark(target_grammar)
    v = parser.parse(open(in_file).read().rstrip())
    exit(0)

if __name__ == '__main__':
    main()

    